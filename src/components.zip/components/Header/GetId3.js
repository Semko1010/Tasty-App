import { useParams } from "react-router-dom";
import Search from "../Search/Search";


const GetId3 = () => {
    let { query } = useParams()
    return (
        <>
            <Search keyword={query} />
        </>
    );
}

export default GetId3;