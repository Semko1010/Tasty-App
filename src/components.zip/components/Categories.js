import React from 'react';

const Categories = () => {
    return ( <div></div> );
}
 
export default Categories;